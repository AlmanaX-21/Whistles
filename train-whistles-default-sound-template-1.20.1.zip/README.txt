Train Whistles Default Sound Template

Requirements
------------
This resource pack requires Minecraft 1.20.1, Train Whistles, and Create 6.0.8-291.

Add these exact Ogg Vorbis files to `assets/whistles/sounds/train_sound/` inside the zip:

  steam_whistle.ogg
  steam_whistle_low.ogg
  steam_horn.ogg
  steam_horn_low.ogg

The files must be Ogg Vorbis. Mono is recommended for positional audio, and seamless loops are recommended. Add only audio you have permission to share. No Create audio is included in this template.

Installation
------------
1. Put this zip in Minecraft's resourcepacks folder.
2. Enable the pack in Minecraft's Resource Packs menu.
3. Press F3+T to reload resources.
4. Reopen the Train Whistles sound selection screen.
5. For multiplayer, distribute the same populated zip to every listener.

Missing files make the matching event silent. You may remove unused event definitions from sounds.json, but keep the remaining JSON valid.
